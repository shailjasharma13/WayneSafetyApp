package wsu.csc5991.wsusafetyapp;

//This class doesn't have corrresponding XML file as it is supposed to have a button only.

public class PowerButtonMenu {

}
